#include <Arduino.h>
#include <SoftwareSerial.h>

#include "config.h"
#include "bluetooth.h"
#include "motors.h"
#include "line_follower.h"


// ================================================================
// BLUETOOTH SERIAL
//
// Arduino RX = D2
// Arduino TX = D3
// ================================================================

SoftwareSerial bluetooth(BT_RX, BT_TX);


// ================================================================
// SYSTEM STATE
// ================================================================

bool autoMode = DEFAULT_AUTO_MODE;

bool obstacleEnabled = DEFAULT_OBSTACLE_ENABLED;

bool buzzerEnabled = DEFAULT_BUZZER_ENABLED;


// Manual movement command
char movementCommand = 'S';


// ================================================================
// INITIALIZE
// ================================================================

void bluetoothBegin() {

  bluetooth.begin(9600);

  // --------------------------------------------------------------
  // SAFE STARTUP STATE
  // --------------------------------------------------------------

  autoMode = false;

  movementCommand = 'S';

  // LFR MUST be disabled when starting.
  lfrSetEnabled(false);

  obstacleEnabled = DEFAULT_OBSTACLE_ENABLED;

  buzzerEnabled = DEFAULT_BUZZER_ENABLED;
}


// ================================================================
// PROCESS BLUETOOTH COMMANDS
// ================================================================

void bluetoothUpdate() {

  while (bluetooth.available()) {

    char command = bluetooth.read();


    // ------------------------------------------------------------
    // Ignore line endings / spaces
    // ------------------------------------------------------------

    if (command == '\r' ||
        command == '\n' ||
        command == ' ') {

      continue;
    }


    // ------------------------------------------------------------
    // MOVEMENT
    // ------------------------------------------------------------

    switch (command) {

      // ----------------------------------------------------------
      // FORWARD
      // ----------------------------------------------------------

      case 'F':
      case 'f':

        // Manual movement automatically leaves AUTO mode.
        autoMode = false;

        // Manual mode means LFR is OFF.
        lfrSetEnabled(false);

        movementCommand = 'F';

        break;


      // ----------------------------------------------------------
      // BACKWARD
      // ----------------------------------------------------------

      case 'B':
      case 'b':

        autoMode = false;

        lfrSetEnabled(false);

        movementCommand = 'B';

        break;


      // ----------------------------------------------------------
      // LEFT
      // ----------------------------------------------------------

      case 'L':
      case 'l':

        autoMode = false;

        lfrSetEnabled(false);

        movementCommand = 'L';

        break;


      // ----------------------------------------------------------
      // RIGHT
      // ----------------------------------------------------------

      case 'R':
      case 'r':

        autoMode = false;

        lfrSetEnabled(false);

        movementCommand = 'R';

        break;


      // ----------------------------------------------------------
      // STOP
      // ----------------------------------------------------------

      case 'S':
      case 's':

        movementCommand = 'S';

        stopMotors();

        break;


      // ==========================================================
      // AUTONOMOUS MODE
      // ==========================================================

      case 'A':
      case 'a':

        // Enter autonomous mode.
        autoMode = true;

        // Autonomous mode automatically enables LFR.
        lfrSetEnabled(true);

        // Cancel any previous manual movement.
        movementCommand = 'S';

        break;


      // ==========================================================
      // MANUAL MODE
      // ==========================================================

      case 'M':
      case 'm':

        // Leave autonomous mode.
        autoMode = false;

        // Manual mode automatically disables LFR.
        lfrSetEnabled(false);

        // Stop the rover when changing mode.
        movementCommand = 'S';

        stopMotors();

        break;


      // ==========================================================
      // OBSTACLE DETECTION
      // ==========================================================

      case 'O':

        obstacleEnabled = true;

        break;


      case 'o':

        obstacleEnabled = false;

        break;


      // ==========================================================
      // BUZZER
      // ==========================================================

      case 'Z':

        buzzerEnabled = true;

        break;


      case 'z':

        buzzerEnabled = false;

        break;


      // ==========================================================
      // UNKNOWN COMMAND
      // ==========================================================

      default:

        // Ignore unknown commands.

        break;
    }
  }
}


// ================================================================
// GET CURRENT MODE
// ================================================================

bool bluetoothIsAutoMode() {

  return autoMode;
}


// ================================================================
// LFR STATE
// ================================================================

bool bluetoothIsLfrEnabled() {

  return lfrIsEnabled();
}


// ================================================================
// OBSTACLE STATE
// ================================================================

bool bluetoothIsObstacleEnabled() {

  return obstacleEnabled;
}


// ================================================================
// BUZZER STATE
// ================================================================

bool bluetoothIsBuzzerEnabled() {

  return buzzerEnabled;
}


// ================================================================
// CURRENT MOVEMENT
// ================================================================

char bluetoothGetMovement() {

  return movementCommand;
}